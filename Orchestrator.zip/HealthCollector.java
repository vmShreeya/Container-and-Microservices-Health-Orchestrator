
public class HealthCollector {

}
